package com.example.book_traders

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
